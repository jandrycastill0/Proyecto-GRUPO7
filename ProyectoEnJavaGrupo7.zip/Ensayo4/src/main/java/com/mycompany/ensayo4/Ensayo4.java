/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ensayo4;

/**
 *
 * @author eddis
 */
public class Ensayo4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
